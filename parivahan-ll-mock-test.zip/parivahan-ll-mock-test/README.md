# Parivahan LL Mock Test

A responsive, static web application for practising Learner's Licence (LL) road-safety and traffic-rule questions.

## Features
- English and Hindi interface and questions
- Timed mock test (15 minutes)
- Untimed practice mode with immediate feedback
- Random question order
- Score summary and answer review
- Responsive layout for phones and desktops

## Run locally
No build tools or dependencies are required.

1. Download or clone this repository.
2. Open `index.html` in a modern browser.

For a local development server, you can run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy with GitHub Pages
1. Create a new GitHub repository and upload these files.
2. Open **Settings → Pages**.
3. Choose **Deploy from a branch**, select `main` and `/ (root)`.
4. Save. GitHub will provide the published URL.

## Important
This is an **unofficial educational practice project**, not a Parivahan or Government of India application. The sample questions are for learning and may not match the current official LL test question bank or state-specific exam. Verify current rules and official practice material through the relevant Parivahan/Sarathi portal.
